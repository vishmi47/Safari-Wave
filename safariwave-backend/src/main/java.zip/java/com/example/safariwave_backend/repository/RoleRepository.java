package com.example.safariwave_backend.repository;

import com.example.safariwave_backend.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role, Integer> {
    Optional<Role> findFirstByRoleNameIgnoreCase(String roleName);
}